Percipience Context Engineering OS - JetBrains Plugin
======================================================
Tested and verified for:
- PyCharm (Professional & Community 2024.1+)
- IntelliJ IDEA (Ultimate & Community 2024.1+)

How to Install for Testing:
1. Open IntelliJ IDEA or PyCharm.
2. Go to Settings / Preferences -> Plugins.
3. Click the ⚙️ (Gear Icon) at the top -> "Install Plugin from Disk...".
4. Select this .zip file ('percipience-intellij-plugin-1.0.0.zip').
5. Restart IDE.
6. The 'Percipience OS' Tool Window will appear on the right-hand panel.
